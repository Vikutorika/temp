# Formerly known as state_handshake_clientbound.
def get_packets(context):
    return set()
